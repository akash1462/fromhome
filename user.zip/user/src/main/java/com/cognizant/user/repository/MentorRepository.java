package com.cognizant.user.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.cognizant.user.model.Mentor;
import com.google.common.base.Optional;

public interface MentorRepository extends JpaRepository<Mentor, Integer>{
	Optional<Mentor> findBylinkedinUrl(String linkedinUrl);
	
}
